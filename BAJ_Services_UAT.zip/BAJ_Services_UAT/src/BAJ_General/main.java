package BAJ_General;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.xml.sax.SAXException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import baj_framework.BAJ_General_ReadConfigFile;
import baj_framework.BAJ_General_SendEmail;
import baj_framework.BAJ_General_ResponseReport;
import baj_framework.BAJ_General_FormatXML;



public class main
{

	
	
  public static void main(String[] args) throws SAXException, ParserConfigurationException, IOException, XPathExpressionException
  {
	  
		 BAJ_General_ReadConfigFile Configuration = new BAJ_General_ReadConfigFile();	  
		 String HTMLReportLocation_ = Configuration.getURLSByName("HTMLReportLocation");	   	  
		 String  HTMLReportLocation = (HTMLReportLocation_+ new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime()) +".html");
		 ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(HTMLReportLocation);
		
	  	        
	     // create ExtentReports and attach reporter(s)
	    ExtentReports extent = new ExtentReports();
	    extent.attachReporter(htmlReporter);
	   
//Read Configuration file and start Report body

	
	// TC 1 Checking Get Account Service Positive. 	
   BAJ_General_ResponseReport tc1_getAccount = null;

	tc1_getAccount = new AccountServices_Steps().TC1_getAccount();
	
	

   // Set TC content 
   ExtentTest test = extent.createTest("TC 1 Checking Get Account Service Positive.", "Bank Aljazzera_UAT");
   // Set test step content
   test.log(tc1_getAccount.getState(), "REQUEST >>>   " +tc1_getAccount.getRequest().replace("<", "&lt;")  );   
   test.log(tc1_getAccount.getState(), "RESPONSE >>>   " +tc1_getAccount.getResponse().replace("<", "&lt;"));   

   
   ExtentTest test2 = extent.createTest("TC 2 Checking Get Account Service", "Bank Aljazzera_UAT");
   // Set test step content
   test2.log(tc1_getAccount.getState(), "REQUEST >>>   " +tc1_getAccount.getRequest().replace("<", "&lt;")  );   
   test2.log(tc1_getAccount.getState(), "RESPONSE >>>   " +tc1_getAccount.getResponse().replace("<", "&lt;"));   
   
   ExtentTest test3 = extent.createTest("TC 3 Checking Get Account", "Bank Aljazzera_UAT");
   // Set test step content
   test3.log(Status.FAIL, "REQUEST >>>   " +tc1_getAccount.getRequest().replace("<", "&lt;")  );   
   test3.log(Status.INFO, "RESPONSE >>>   " +tc1_getAccount.getResponse().replace("<", "&lt;"));   
   
   ExtentTest test4 = extent.createTest("TC 6 Checking Get Account Service Negative.", "Bank Aljazzera_UAT");
   // Set test step content
   test4.log(Status.FAIL, "REQUEST >>>   " +tc1_getAccount.getRequest().replace("<", "&lt;")  );   
   test4.log(Status.PASS, "RESPONSE >>>   " +tc1_getAccount.getResponse().replace("<", "&lt;"));   
   
   
   
   
   
   	// Generate Report 
    extent.flush();
	//Sending email    
    BAJ_General_SendEmail SendEmail = new BAJ_General_SendEmail();
    SendEmail.sendEmail(HTMLReportLocation);
    
    
  }
}
