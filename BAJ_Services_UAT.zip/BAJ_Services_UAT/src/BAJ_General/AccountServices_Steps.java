package BAJ_General;



import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;

import javax.swing.text.Document;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import javax.xml.xpath.XPathExpressionException;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import baj_framework.BAJ_General_VerifySOAPResponse;
import baj_framework.BAJ_General_TimeDate;
import baj_framework.BAJ_General_ValidateSchema;
import baj_framework.BAJ_General_GetValidCredentials;
import baj_framework.BAJ_General_ReadConfigFile;
import baj_framework.BAJ_General_ResponseReport;
import baj_framework.XmlParser;
import baj_framework.BAJ_General_SetEnvironmentalVaribales;

public class AccountServices_Steps {

	BAJ_General_TimeDate GetCurrentDateTime = new BAJ_General_TimeDate();
	String  Password =  BAJ_General_GetValidCredentials.GetValidCredentials();
	BAJ_General_ReadConfigFile Configuration = new BAJ_General_ReadConfigFile();
	String Channel_ID = Configuration.getURLSByName("Channel_ID");
	String language = Configuration.getURLSByName("language");
	String JOL_customerNo = Configuration.getURLSByName("JOL_customerNo");
	String TestAgainst = Configuration.getURLSByName("TestAgainst");
	 


	
	public BAJ_General_ResponseReport TC1_getAccount() throws SAXException, ParserConfigurationException, IOException, XPathExpressionException
	{

		String request = null;
		String request_Updated = null;

		if(TestAgainst.equalsIgnoreCase("WAS"))
		{

			  request = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:acc=\"http://account.webservice.eai.baj.com.sa/\">\r\n" + 
			  		"   <soapenv:Header>\r\n" + 
			  		"      <acc:requestHeader>\r\n" + 
			  		"         <language>%s</language>\r\n" + 
			  		"         <requestID>%s</requestID>\r\n" + 
			  		"         <userID>JOLUser1/%s</userID>\r\n" + 
			  		"         <customerNo>%s</customerNo>\r\n" + 
			  		"         <channelID>%s</channelID>\r\n" + 
			  		"      </acc:requestHeader>\r\n" + 
			  		"   </soapenv:Header>\r\n" + 
			  		"   <soapenv:Body>\r\n" + 
			  		"      <acc:getAccountList>\r\n" + 
			  		"         <getAccountsListRequest>\r\n" + 
			  		"            <customerNo>%s</customerNo>\r\n" + 
			  		"         </getAccountsListRequest>\r\n" + 
			  		"      </acc:getAccountList>\r\n" + 
			  		"   </soapenv:Body>\r\n" + 
			  		"</soapenv:Envelope>";
			  			  			  
			  
			    request_Updated = String.format(request, language, GetCurrentDateTime.GetCurrentDateTime(),Password,JOL_customerNo,Channel_ID,JOL_customerNo);

			    
			    
		}
		else if(TestAgainst.equalsIgnoreCase("MB"))
		{		
			
			boolean ValidateSchemaFlag =true;
			request_Updated = "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:acc=\"http://accountServices\">\r\n" + 
			 		"   <soap:Header>\r\n" + 
			 		"      <acc:requestHeader>\r\n" + 
			 		"         <language>"+language+ "</language>\r\n" + 
			 		"         <requestID>Automation_getAccountList" + GetCurrentDateTime.GetCurrentDateTime() +" </requestID>\r\n" + 
			 		"         <userID>JOLUser1/" +Password+ "</userID>\r\n" + 
			 		"         <customerNo>"+JOL_customerNo+"</customerNo>\r\n" + 
			 		"         <channelID>"+ Channel_ID+"</channelID>\r\n" + 
			 		"         <tokenKey></tokenKey>       \r\n" + 
			 		"         <cuid></cuid>\r\n" + 
			 		"         <idNumber></idNumber>\r\n" + 
			 		"      </acc:requestHeader>\r\n" + 
			 		"   </soap:Header>\r\n" + 
			 		"   <soap:Body>\r\n" + 
			 		"<ns2:getAccountsListRequest xmlns:ns2=\"http://accountServices\" xmlns:ns3=\"http://com.baj.retailServices\">" + 
			 		"         <customerNo>"+JOL_customerNo+"</customerNo>" + 
			 		"</ns2:getAccountsListRequest>" + 
			 		"   </soap:Body>\r\n" + 
			 		"</soap:Envelope>"	;
				
		    request_Updated = String.format(request_Updated, language, GetCurrentDateTime.GetCurrentDateTime(),Password,JOL_customerNo,Channel_ID,JOL_customerNo);			 					

		    BAJ_General_ValidateSchema   ValidateSchema  = new  BAJ_General_ValidateSchema();
		    try {
				ValidateSchema.ValidateSchema_getAccountsListRequest(request_Updated);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				ValidateSchemaFlag = false;
			}
		}
		else
		{
			 request = null;
			
			//Report please 
		 //   rsrp.setMessage(DescriptionResponse);
			
		}		
		BAJ_General_ResponseReport rsrp = BAJ_General_VerifySOAPResponse.VerifySOAPResponse(request_Updated);
		return rsrp;
	}

}

