package baj_framework;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathException;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class BaseParser {
	private Document doc; 
	
	protected BaseParser(){}
	/**
	 * @param fileName
	 * To load file from default configurations folder
	 * @throws SAXException 
	 * @throws ParserConfigurationException 
	 * @throws IOException 
	 * @throws FrameworkException 
	 */
	protected BaseParser(String xmlString) throws IOException, ParserConfigurationException, SAXException {
		loadFromXmlString(xmlString);	
	}
	
	
	protected BaseParser(StringBuilder xmlString) throws ParserConfigurationException, SAXException, IOException {
		loadFromXmlString(xmlString.toString());
	}
	

	private void loadFromXmlString(String xmlString) throws ParserConfigurationException, SAXException, IOException {
	
		StringReader sr=new StringReader(xmlString.trim());
		InputSource is=new InputSource(sr);
		
		DocumentBuilderFactory  factory=DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(false);
		factory.setIgnoringComments(true);
		factory.setIgnoringElementContentWhitespace(true);
		
		DocumentBuilder builder;
		builder = factory.newDocumentBuilder();
		this.doc=builder.parse(is);
		removeEmptyTextNodes(this.doc.getDocumentElement());
		
		
	}
	
	/**
	 * Remove the empty text nodes from the document
	 * Imad
	 * @param parent
	 */
	private void removeEmptyTextNodes(Element parent){	
		try {
			XPath xp = XPathFactory.newInstance().newXPath();
			NodeList nl;

			nl = (NodeList) xp.evaluate("//text()[normalize-space(.)='']", doc, XPathConstants.NODESET);

			for (int i = 0; i < nl.getLength(); ++i) {
				Node node = nl.item(i);
				node.getParentNode().removeChild(node);
			}

		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	private void removeIgnorableWSNodes(Element parent){
		Node nextNode=parent.getFirstChild();
		for (Node child=parent.getFirstChild(); nextNode!=null;) {
			child=nextNode;
			nextNode=child.getNextSibling();
			if(child.getNodeType()==Node.TEXT_NODE){
					parent.removeChild(child);
			}
			else if(child.getNodeType()==Node.ELEMENT_NODE){
				removeIgnorableWSNodes((Element)child);
			}
		}
	}
	protected Document getDoc() {
		return doc;
	}
	
	protected Node getNode(Node parentNode, String nodeName) {
		Node node = null;
		try {

			XPath xPath = XPathFactory.newInstance().newXPath();
			String expression = nodeName;//+ "/text()";

			XPathExpression expr = xPath.compile(expression);
			Object result = expr.evaluate(parentNode, XPathConstants.NODE);

			if (result != null) {
				node = (Node) result;
				
			}
		} catch (XPathException xpathEx) {
			// TODO: log this exception
			System.out.println(xpathEx.getMessage());
		} catch (Exception e) {
			// TODO: log this exception
			System.out.println(e.getMessage());
		}
		return node;
	}
	
	protected Node getNode(Node parentNode,String nodeName, String attrName,String attrValue){
		Node node = null;
		try {

			XPath xPath = XPathFactory.newInstance().newXPath();
			String expression = nodeName+"[@"+attrName+"='"+attrValue+"']";//+"/text()";

			XPathExpression expr = xPath.compile(expression);
			Object result = expr.evaluate(parentNode, XPathConstants.NODE);

			if (result != null) {
				node = (Node) result;
			}
		} catch (XPathException xpathEx) {
			// TODO: log this exception
			System.out.println(xpathEx.getMessage());
		} catch (Exception e) {
			// TODO: log this exception
			System.out.println(e.getMessage());
		}
		return node;
	}
}
