package baj_framework;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

/**

 */
public class BAJ_General_GetValidCredentials {

	
	
	
	  static BAJ_General_ReadConfigFile ConfigurationFileData = new BAJ_General_ReadConfigFile();

	  public static String DB_HostName = ConfigurationFileData.getURLSByName("DB_HostName");
	  public static String DB_Port = ConfigurationFileData.getURLSByName("DB_Port");
	  public static String DB_ServiceName = ConfigurationFileData.getURLSByName("DB_ServiceName");
	  public static String DB_UserName = ConfigurationFileData.getURLSByName("DB_UserName");
	  public static String DB_Password = ConfigurationFileData.getURLSByName("DB_Password");

	
	
    public static String GetValidCredentials(){
    	String password = null;
    	try
    	{
        //URL of Oracle database server
        String url = "jdbc:oracle:thin:@//"+ DB_HostName +":"+ DB_Port +"/"+ DB_ServiceName+""; 

        //properties for creating connection to Oracle database
        Properties props = new Properties();
        props.setProperty("user", ""+DB_UserName +"");
        props.setProperty("password",""+DB_Password +"");
      
        //creating connection to Oracle database using JDBC
        Connection conn = DriverManager.getConnection(url,props);

        String sql ="select Password from t_frm_user_profile where channel =  'JOL' and ROWNUM <= 1";

        //creating PreparedStatement object to execute query
        PreparedStatement preStatement = conn.prepareStatement(sql);
    
        ResultSet result = preStatement.executeQuery();
        //System.out.println(result);
        while(result.next()){
          //  System.out.println("JOL Password is " +    result.getString("Password"));
        	password =result.getString("Password").trim();
        }
                
        //Reporter
        System.out.println("done-Reporter needed");
        
         
    	}
    	catch(Exception ex)
    	{
    		ex.printStackTrace();
    	}
      return password;
    }
}
