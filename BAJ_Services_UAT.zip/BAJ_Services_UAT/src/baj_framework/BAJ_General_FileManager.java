package baj_framework;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class BAJ_General_FileManager
{
	
	  /*
	  <PublicVariable_Config>

			      <PublicVariable value = "TestAgainst">
				   	  <value>WAS</value>
			     </PublicVariable>
	     <URLS>

			     <URL name = "yakeen">
				      <name>http://yakeen-piloting.eserve.com.sa/Yakeen4BAJWS/Yakeen4BAJWS</name>
			     </URL>         
	          
	   */
  String[] Names;
  String[] reqNames;
  String[] req;
  String[] URLS;
  String[] reqString;
  
  public void openURL(String filename)
  {
    List<String> namesArray = new ArrayList();
    List<String> URLSArray = new ArrayList();
    File xmlFile = new File(filename);
    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
    try
    {
      DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
      try
      {
        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();
        NodeList nList = doc.getElementsByTagName("URL");
        for (int i = 0; i < nList.getLength(); i++)
        {
          Node nNode = nList.item(i);
          if (nNode.getNodeType() == 1)
          {
            Element eElement = (Element)nNode;
            namesArray.add(eElement.getAttribute("name"));
            URLSArray.add(eElement.getElementsByTagName("name").item(0).getTextContent());
          }
        }
        this.Names = new String[namesArray.size()];
        this.Names = ((String[])namesArray.toArray(this.Names));
        this.URLS = new String[URLSArray.size()];
        this.URLS = ((String[])URLSArray.toArray(this.URLS));
      }
      catch (SAXException e)
      {
        e.printStackTrace();
      }
      catch (IOException e)
      {
        e.printStackTrace();
      }
      return;
    }
    catch (ParserConfigurationException e)
    {
      e.printStackTrace();
    }
  }
  
  public void openReq(String filename)
  {
    List<String> namesArray = new ArrayList();
    List<String> reqArray = new ArrayList();
    File xmlFile = new File(filename);
    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
    try
    {
      DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
      try
      {
        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();
        NodeList nList = doc.getElementsByTagName("request");
        for (int i = 0; i < nList.getLength(); i++)
        {
          Node nNode = nList.item(i);
          if (nNode.getNodeType() == 1)
          {
            Element eElement = (Element)nNode;
            namesArray.add(eElement.getElementsByTagName("name").item(0).getTextContent());
            reqArray.add(eElement.getElementsByTagName("req").item(0).getTextContent());
          }
        }
        this.reqNames = new String[namesArray.size()];
        this.reqNames = ((String[])namesArray.toArray(this.reqNames));
        this.req = new String[reqArray.size()];
        this.req = ((String[])reqArray.toArray(this.req));
      }
      catch (SAXException e)
      {
        e.printStackTrace();
      }
      catch (IOException e)
      {
        e.printStackTrace();
      }
      return;
    }
    catch (ParserConfigurationException e)
    {
      e.printStackTrace();
    }
  }
  
  public void OpenGetRequestString(String text)
  {
    List<String> getReq = new ArrayList();
    String[] splitxml = text.split("<req>");
    for (int i = 0; i < splitxml.length; i++) {
      if (splitxml[i].indexOf("</req>") != -1)
      {
        String c = splitxml[i].substring(0, splitxml[i].indexOf("</req>"));
        getReq.add(c);
      }
    }
    this.reqString = new String[getReq.size()];
    this.reqString = ((String[])getReq.toArray(this.reqString));
  }
  
  public void getRequestFile(String filename)
  {
    BufferedReader br = null;
    
    String readFile = null;
    String[] splitfile = null;
    List<String> getReq = new ArrayList();
    try
    {
      br = new BufferedReader(new FileReader(filename));
      try
      {
        String read = null;
        while ((read = br.readLine()) != null)
        {
          readFile = readFile + read;
        }
        br.close();
      }
      catch (IOException e)
      {
        e.printStackTrace();
      }
      splitfile = readFile.split("<req>");
    }
    catch (FileNotFoundException e)
    {
      e.printStackTrace();
    }
    //String[] splitfile;
    for (int i = 0; i < splitfile.length; i++) {
      if (splitfile[i].indexOf("</req>") != -1)
      {
        String c = splitfile[i].substring(0, splitfile[i].indexOf("</req>"));
        getReq.add(c);
      }
    }
    this.reqString = new String[getReq.size()];
    this.reqString = ((String[])getReq.toArray(this.reqString));
  }
  
  public String[] getAllNames()
  {
    return this.Names;
  }
  
  public String getNames(int position)
  {
    return this.Names[position];
  }
  
  public String[] getAllURLS()
  {
    return this.URLS;
  }
  
  public String getURLS(int position)
  {
    return this.URLS[position];
  }
  
  public String getURLSByName(String name)
  {
    for (int i = 0; i < this.Names.length; i++) {
      if (this.Names[i].equals(name)) {
        return getURLS(i);
      }
    }
    return "not found";
  }
  
  public String[] getAllreqNames()
  {
    return this.reqNames;
  }
  
  public String getReqNames(int position)
  {
    return this.reqNames[position];
  }
  
  public String[] getAllReq()
  {
    return this.req;
  }
  
  public String getReq(int position)
  {
    return this.req[position];
  }
  
  public String[] getReqSAll()
  {
    return this.reqString;
  }
  
  public String getReqSAt(int position)
  {
    return this.reqString[position];
  }
}
