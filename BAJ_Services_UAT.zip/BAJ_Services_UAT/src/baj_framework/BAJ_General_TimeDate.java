package baj_framework;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.function.Function;

public class BAJ_General_TimeDate {


	
	
	public static String GetCurrentDateTime() {
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
		return timeStamp;
		
		}
}
	