package baj_framework;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class BAJ_General_SendEmail {
	
	public void sendEmail(String ReportLocation)
	{
		
		BAJ_General_ReadConfigFile Configuration = new BAJ_General_ReadConfigFile();
		String TestAgainst = Configuration.getURLSByName("TestAgainst");
		String Channel_ID = Configuration.getURLSByName("Channel_ID");			
		
		String CurrentDateTime = new  SimpleDateFormat("yyyyMMdd_HHmm").format(Calendar.getInstance().getTime());

	 // Recipient's email ID needs to be mentioned.
    String to = "MAAlzait@BAJ.Com.SA";

    // Sender's email ID needs to be mentioned
    String from = "UAT@BAJ.Com.SA";

   // final String username = "manishaspatil";//change accordingly
   // final String password = "******";//change accordingly

    // Assuming you are sending email through relay.jangosmtp.net
    String host = "exsmtp01.baj.com.sa";

    Properties props = new Properties();
    props.put("mail.smtp.auth", "false");
    props.put("mail.smtp.starttls.enable", "true");
    props.put("mail.smtp.host", host);
    props.put("mail.smtp.port", "25");
    
    Session session = Session.getInstance(props);
    

    try {
       // Create a default MimeMessage object.
       Message message = new MimeMessage(session);

       // Set From: header field of the header.
       message.setFrom(new InternetAddress(from));
   
       // Set To: header field of the header.
       message.setRecipients(Message.RecipientType.TO,
          InternetAddress.parse(to));

       // Set Subject: header field
       message.setSubject("Automation Report_"+TestAgainst+"_" +Channel_ID+"_" +CurrentDateTime+"");
       // Create the message part
       BodyPart messageBodyPart = new MimeBodyPart();
       // Now set the actual message
       messageBodyPart.setText("Testing Automation Report \n Kindly check the attachement for more info.\n Regards, \n Automation Team");

       // Create a multipar message
       Multipart multipart = new MimeMultipart();

       // Set text message part
       multipart.addBodyPart(messageBodyPart);

       // Part two is attachment
       messageBodyPart = new MimeBodyPart();
       String ReportLocation_ = ReportLocation;
       DataSource source = new FileDataSource(ReportLocation_);
       messageBodyPart.setDataHandler(new DataHandler(source));
       messageBodyPart.setFileName("Automation Report.html");
       //messageBodyPart.setText("hjsgxcsdvhcwhsdv");
       multipart.addBodyPart(messageBodyPart);

       // Send the complete message parts
       message.setContent(multipart);

       // Send message
       Transport.send(message);

       System.out.println("Sent message successfully....");

    } catch (MessagingException e) {
       throw new RuntimeException(e);
    }
	}
}
