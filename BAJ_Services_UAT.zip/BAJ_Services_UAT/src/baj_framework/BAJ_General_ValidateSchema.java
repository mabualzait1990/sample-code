package baj_framework;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;

import com.aventstack.extentreports.ExtentTest;

//ServiceName and XSD path should be in DB and the function should be general

public class BAJ_General_ValidateSchema {

	public  void ValidateSchema_getAccountsListRequest(String request) throws Exception, SAXException, IOException
	{
		BAJ_General_ReadConfigFile Configuration = new BAJ_General_ReadConfigFile();

		String getAccountsListRequest = Configuration.getURLSByName("ServiceName_getAccountsListRequest");
		//Save to DB 
		String xsd_getAccountsListRequest = Configuration.getURLSByName("xsd_getAccountsListRequest");

		
		XmlParser xmlParser = new XmlParser(request);				
		String Request = xmlParser.getNode("Envelope/Body/"+getAccountsListRequest);
		SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);                  
		Source sourceSchema=new StreamSource(xsd_getAccountsListRequest);
        Schema schema = factory.newSchema(sourceSchema);
        Validator validator = schema.newValidator();
        Source source = new StreamSource(new StringReader(Request));                                                    
        validator.validate(source);
           

		
		
	}
}
