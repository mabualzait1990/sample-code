package baj_framework;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class XmlParser extends BaseParser {

public XmlParser(String requestForValidation) throws ParserConfigurationException, SAXException, IOException {
	super(requestForValidation);
}

	public String getNode(String path) throws XPathExpressionException, TransformerFactoryConfigurationError 
	{
		Node node = null;
		XPath xPath = XPathFactory.newInstance().newXPath();
	
		XPathExpression expr = xPath.compile(path);
		Object result = expr.evaluate(this.getDoc(), XPathConstants.NODE);

		if (result != null) {
			node = (Node) result;
			StringWriter sw = new StringWriter();
			 Transformer t;
			try {
				t = TransformerFactory.newInstance().newTransformer();
				 t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
				    t.transform(new DOMSource(node), new StreamResult(sw));
				    
				    return sw.toString();
			} catch (TransformerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			   
		}
		return null;
	}
	
	public String getNodeList(String path,int index) throws XPathExpressionException 
	{
		XPath xPath = XPathFactory.newInstance().newXPath();
	
		XPathExpression expr = xPath.compile(path);
		Object result = expr.evaluate(this.getDoc(), XPathConstants.NODESET);
		NodeList nodes = (NodeList) result;
	
		if (result != null)
		{
			nodes = (NodeList) result;
			return nodes.item(index).getTextContent();
		}
		return null;
	}
	
	public int nodeListSize(String message,String elementList) throws Exception
	{
		int size;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Reader xml = new StringReader(message);
		Document doc = builder.parse(new InputSource(xml));

		NodeList nList = doc.getElementsByTagName(elementList);
		size = nList.getLength();
		return size;
	}
}
