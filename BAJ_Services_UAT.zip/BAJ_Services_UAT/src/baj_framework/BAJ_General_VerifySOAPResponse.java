package baj_framework;

import com.aventstack.extentreports.Status;

public class BAJ_General_VerifySOAPResponse {

	public static BAJ_General_ResponseReport VerifySOAPResponse(String request) {
		
		
		
		BAJ_General_ReadConfigFile Configuration = new BAJ_General_ReadConfigFile();
		String TestAgainst = Configuration.getURLSByName("TestAgainst");
		BAJ_General_SetEnvironmentalVaribales EnvironmentalVaribales = new BAJ_General_SetEnvironmentalVaribales();	  	  	
		String IPFirstPart = EnvironmentalVaribales.GetFullIPAddress( Configuration.getURLSByName("Track_IP"), Configuration.getURLSByName("Track_Port"), Configuration.getURLSByName("Secure_Flag"));
		
		String AccountServices_URL = null;		

		if(TestAgainst.equalsIgnoreCase("WAS"))
		{
			 AccountServices_URL = Configuration.getURLSByName("AccountServices_WAS");			
		}
	
		else if(TestAgainst.equalsIgnoreCase("MB"))
		{
			 AccountServices_URL = Configuration.getURLSByName("AccountServices_MB");
	
		}
		else
		{
		 request = null;
		
		 		//Report please 
		 		//	rsrp.setState(Status.FAIL);
		 		//   rsrp.setMessage(DescriptionResponse);		
		}		
	

		String response = null;
		
		
		String FullURLAddress = IPFirstPart + AccountServices_URL;

		BAJ_General_ResponseReport rsrp = new BAJ_General_ResponseReport();
		
	   
		BAJ_General_GetSOAPResponse connection = new BAJ_General_GetSOAPResponse();
		connection.Connect(request, FullURLAddress);
		response = connection.getResponse();
		
		int startState = response.indexOf("<state>")+7;
		int endState = response.indexOf("</state>");
		String stateResponse = response.substring(startState, endState);
		
		int startDes = response.indexOf("<description>")+13;
		int endDes = response.indexOf("</description>");
		
		String DescriptionResponse = response.substring(startDes, endDes);
		
		if(stateResponse.equalsIgnoreCase("Successful"))
		{
			rsrp.setState(Status.PASS);
		}
		else if(stateResponse.equalsIgnoreCase("WARNING"))
		{
			
			rsrp.setState(Status.WARNING);
			
		}
		else if(stateResponse.equalsIgnoreCase(""))
		{
			
			rsrp.setState(Status.WARNING);
			
		}	
		else if(stateResponse.equalsIgnoreCase("FAILURE"))
		{
			
			rsrp.setState(Status.FAIL);
			
		}		
		
		else
		{
			
			rsrp.setState(Status.FAIL);
			
		}		
		
		
		rsrp.setMessage(DescriptionResponse);
		rsrp.setResponse(response);
		rsrp.setRequest(request);
		return rsrp;
		
		
	}
	
}
