package baj_framework;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class BAJ_General_GetSOAPResponse
{
  String outputString = "";
  HttpURLConnection httpConn = null;
  HttpsURLConnection httpsConn = null;
  String ERROR = null;
  
  public void Connect(String message, String URL)
  {
    if (this.outputString.length() > 0) {
      this.outputString = "";
    }
    URL url = null;
    URLConnection connection = null;
    String responseString = null;
    ByteArrayOutputStream bout = null;
    OutputStream out = null;
    InputStreamReader isr = null;
    BufferedReader in = null;
    try
    {
      if (URL.indexOf("http://") != -1)
      {
        url = new URL(URL);
        connection = url.openConnection();
        this.httpConn = ((HttpURLConnection)connection);
        bout = new ByteArrayOutputStream();
        byte[] buffer = new byte[message.length()];
        buffer = message.getBytes();
        bout.write(buffer);
        byte[] b = bout.toByteArray();
        String SOAPAction = "";
        this.httpConn.setRequestProperty("Content-Length", 
          String.valueOf(b.length));
        this.httpConn.setRequestProperty("Content-Type", 
          "text/xml; charset=utf-8");
        this.httpConn.setRequestProperty("SOAPAction", SOAPAction);
        this.httpConn.setRequestMethod("POST");
        this.httpConn.setDoOutput(true);
        this.httpConn.setDoInput(true);
        out = this.httpConn.getOutputStream();
        
        out.write(b);
        out.close();
        isr = new InputStreamReader(this.httpConn.getInputStream());
        in = new BufferedReader(isr);
        while ((responseString = in.readLine()) != null) {
          this.outputString += responseString;
        }
      }
      else if (URL.indexOf("https://") != -1)
      {
        TrustManager[] trustAllCerts = {
          new X509TrustManager()
          {
            public X509Certificate[] getAcceptedIssuers()
            {
              return null;
            }
            
            public void checkClientTrusted(X509Certificate[] certs, String authType) {}
            
            public void checkServerTrusted(X509Certificate[] certs, String authType) {}
          } };
        try
        {
          SSLContext sc = SSLContext.getInstance("SSL");
          sc.init(null, trustAllCerts, new SecureRandom());
          HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        }
        catch (Exception localException) {}
        url = new URL(URL);
        connection = url.openConnection();
        this.httpsConn = ((HttpsURLConnection)connection);
        this.httpsConn.setHostnameVerifier(new HostnameVerifier()
        {
          public boolean verify(String hostname, SSLSession session)
          {
            System.out.println(hostname);
            return true;
          }
        });
        bout = new ByteArrayOutputStream();
        byte[] buffer = new byte[message.length()];
        buffer = message.getBytes();
        bout.write(buffer);
        byte[] b = bout.toByteArray();
        String SOAPAction = "";
        this.httpsConn.setRequestProperty("Content-Length", 
          String.valueOf(b.length));
        this.httpsConn.setRequestProperty("Content-Type", 
          "text/xml; charset=utf-8");
        this.httpsConn.setRequestProperty("SOAPAction", SOAPAction);
        this.httpsConn.setRequestMethod("POST");
        this.httpsConn.setDoOutput(true);
        this.httpsConn.setDoInput(true);
        out = this.httpsConn.getOutputStream();
        
        out.write(b);
        out.close();
        isr = new InputStreamReader(this.httpsConn.getInputStream());
        in = new BufferedReader(isr);
        while ((responseString = in.readLine()) != null) {
          this.outputString += responseString;
        }
      }
    }
    catch (MalformedURLException e)
    {
      this.ERROR = e.getMessage();
    }
    catch (IOException e)
    {
      this.ERROR = e.getMessage();
    }
  }
  
  public String getResponse()
  {
    return this.outputString.toString();
  }
  
  public String getHeaderField(String con, int header)
  {
    if (con.indexOf("http://") != -1) {
      return this.httpConn.getHeaderField(header);
    }
    if (con.indexOf("https://") != -1) {
      return this.httpsConn.getHeaderField(header);
    }
    return "null";
  }
  
  public String getERROR()
  {
    return this.ERROR;
  }
}
