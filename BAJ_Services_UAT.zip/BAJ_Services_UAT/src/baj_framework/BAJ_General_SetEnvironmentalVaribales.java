package baj_framework;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.swing.DefaultComboBoxModel;


public class BAJ_General_SetEnvironmentalVaribales {

	
	
	
	
	 public String GetFullIPAddress(String TrackName,String Port,String secure_Flag){

		 		String punctuation = ":";		 							
				String URL_Secure;								

								
				
			        if (secure_Flag.equalsIgnoreCase("true")) {
			        	URL_Secure = "https://";
			        } else if (secure_Flag.equalsIgnoreCase("false")) {
			        	URL_Secure = "http://";

			        } else {
			        	URL_Secure = null;
			        	//Reporter
				      

			        }
			        			        			       

				    //Read the URLs file
				    BAJ_General_FileManager URL = new BAJ_General_FileManager();
					
					  try
					    {
					      String current = new File(".").getCanonicalPath();
					      System.out.println(current);
					      URL.openURL(current + "\\URLS.xml");
					      DefaultComboBoxModel model = new DefaultComboBoxModel(URL.getAllURLS());
					     // DefaultComboBoxModel model2 = new DefaultComboBoxModel(URL.getAllReq());

					    }
					    catch (IOException e)
					    {
					      e.printStackTrace();
					    }    			  
					
					  
					  BAJ_General_ReadConfigFile Configuration = new BAJ_General_ReadConfigFile();

					  try
					    {
					      String current = new File(".").getCanonicalPath();
					      System.out.println(current);
					      Configuration.openURL(current + "\\Configuration.xml");
					      DefaultComboBoxModel model = new DefaultComboBoxModel(Configuration.getAllURLS());
					     // DefaultComboBoxModel model2 = new DefaultComboBoxModel(URL.getAllReq());

					    }
					    catch (IOException e)
					    {
					      e.printStackTrace();
					    }    			  	        			        
			  	
			  	
					  String Full_URL = URL_Secure+TrackName+punctuation+Port;			        
					return Full_URL;
	 }
	 
	 


}
