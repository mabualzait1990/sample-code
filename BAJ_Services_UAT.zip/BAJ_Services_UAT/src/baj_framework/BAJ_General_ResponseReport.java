package baj_framework;

import com.aventstack.extentreports.Status;

public class BAJ_General_ResponseReport {

	private Status state;
	private String message;
	private String response;
	private String request;
	
	
	public Status getState() {
		return state;
	}
	public void setState(Status state) {
		this.state = state;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	public String getRequest() {
		return request;
	}
	public void setRequest(String request) {
		this.request = request;
	}
	
	
	
}
