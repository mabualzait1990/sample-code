package com.aventstack.extentreports.gherkin.model;

public class Given implements IGherkinFormatterModel {

}
