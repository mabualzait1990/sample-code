package com.aventstack.extentreports.reporter.configuration;

/**
 * For {@link com.aventstack.extentreports.reporter.ExtentHtmlReporter}, sets the location of charts 
 */
public enum ChartLocation {
    TOP,
    BOTTOM
}
