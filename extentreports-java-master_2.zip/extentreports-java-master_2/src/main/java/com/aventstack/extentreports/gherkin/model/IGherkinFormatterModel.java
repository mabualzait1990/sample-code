package com.aventstack.extentreports.gherkin.model;

public interface IGherkinFormatterModel { }
