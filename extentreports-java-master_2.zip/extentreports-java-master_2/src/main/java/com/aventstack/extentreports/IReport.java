package com.aventstack.extentreports;

public interface IReport {
    
}
