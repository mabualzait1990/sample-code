package com.aventstack.extentreports.gherkin.model;

public class Background implements IGherkinFormatterModel {

}
