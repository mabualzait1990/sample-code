package com.aventstack.extentreports.gherkin.model;

public class When implements IGherkinFormatterModel {

}
