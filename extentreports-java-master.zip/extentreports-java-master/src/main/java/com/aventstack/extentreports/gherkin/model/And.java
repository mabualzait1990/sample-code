package com.aventstack.extentreports.gherkin.model;

public class And implements IGherkinFormatterModel {

}
