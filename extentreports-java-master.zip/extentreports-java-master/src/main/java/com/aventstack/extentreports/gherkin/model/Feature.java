package com.aventstack.extentreports.gherkin.model;

public class Feature implements IGherkinFormatterModel {

}
