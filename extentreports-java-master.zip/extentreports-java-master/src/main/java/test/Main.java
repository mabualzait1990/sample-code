package test;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class Main {
    public static void main(String[] args) throws IOException {
        // start reporters
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("extent_new55dddd.html");
    
        // create ExtentReports and attach reporter(s)
        ExtentReports extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        // creates a toggle for the given test, adds all log events under it    
        ExtentTest test = extent.createTest("MyFirstTest", "Sample description");

        // log(Status, details)
        test.log(Status.PASS, "This step shows usage of log(status, details)");
        test.log(Status.FAIL, "This step shows usage of log(status, details)");
        test.log(Status.PASS, "This step shows usage of log(status, details)");
        test.log(Status.PASS, "test passed");
        test.log(Status.PASS, "okay");

        // info(details)
        test.info("This step shows usage of info(details)");
        
        // log with snapshot
       // test.fail("details", MediaBuilder.createScreenCaptureFromPath("screenshot.png").build());
        
        // test with snapshot
      //  test.addScreenCaptureFromPath("screenshot.png");
        
        // calling flush writes everything to the log file
        
        
        ExtentTest test2 = extent.createTest("BAJ_Second", "Account settings");
        test2.log(Status.PASS, "okay");
        extent.flush();

    }
}